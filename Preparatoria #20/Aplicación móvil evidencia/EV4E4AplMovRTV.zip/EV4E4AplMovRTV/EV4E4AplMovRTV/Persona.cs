﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EV4E4AplMovRTV
{
    class Persona
    {
        //Atributos
        String nombre { get; set; }
        DateTime fechaNac { get; set; }
        String sexo { get; set; }
        double peso { get; set; }
        double altura { get; set; }
        
        //Método constructor
        public Persona(String nombre, DateTime fechaNac, String sexo, double peso, double altura)
        {
            this.nombre = nombre;
            this.fechaNac = fechaNac;
            this.sexo = sexo;
            this.peso = peso;
            this.altura = altura;
        }

        //Métodos
        public int calculaEdad()
        {
            DateTime fechaActual = DateTime.Today;
            int calendar_years = fechaActual.Year - fechaNac.Year;
            int edad = calendar_years - ((fechaActual.AddYears(-calendar_years) >= fechaNac) ? 0 : 1);
            return edad;
        }

        public double CalcularIMC()
        {
            double IMC = peso / Math.Pow(altura, 2);
            return IMC;
        }

        public double[] Calcularsalud()
        {
            double[] nivelesIMC = new double[4];
            int edad = calculaEdad();
            if (sexo == "Hombre")
            {
                switch (edad)
                {
                    case 10:
                        nivelesIMC[0] = 13.7;
                        nivelesIMC[1] = 18.5;
                        nivelesIMC[2] = 21.4;
                        break;

                    case 11:
                        nivelesIMC[0] = 14.1;
                        nivelesIMC[1] = 19.2;
                        nivelesIMC[2] = 22.5;
                        break;

                    case 12:
                        nivelesIMC[0] = 14.5;
                        nivelesIMC[1] = 19.9;
                        nivelesIMC[2] = 23.6;
                        break;

                    case 13:
                        nivelesIMC[0] = 14.9;
                        nivelesIMC[1] = 20.8;
                        nivelesIMC[2] = 24.8;
                        break;

                    case 14:
                        nivelesIMC[0] = 15.5;
                        nivelesIMC[1] = 21.8;
                        nivelesIMC[2] = 25.9;
                        break;

                    case 15:
                        nivelesIMC[0] = 16.0;
                        nivelesIMC[1] = 22.7;
                        nivelesIMC[2] = 27.0;
                        break;
                        default:
                        nivelesIMC[0] = 0;
                        break;


                }
            }else
            {
                switch (edad)
                {
                    case 10:
                        nivelesIMC[0] = 13.5;
                        nivelesIMC[1] = 19.0;
                        nivelesIMC[2] = 22.6;
                        break;

                    case 11:
                        nivelesIMC[0] = 13.9;
                        nivelesIMC[1] = 19.9;
                        nivelesIMC[2] = 23.7;
                        break;

                    case 12:
                        nivelesIMC[0] = 14.4;
                        nivelesIMC[1] = 20.8;
                        nivelesIMC[2] = 25.0;
                        break;

                    case 13:
                        nivelesIMC[0] = 14.9;
                        nivelesIMC[1] = 21.8;
                        nivelesIMC[2] = 26.2;
                        break;

                    case 14:
                        nivelesIMC[0] = 15.4;
                        nivelesIMC[1] = 22.7;
                        nivelesIMC[2] = 27.3;
                        break;

                    case 15:
                        nivelesIMC[0] = 15.9;
                        nivelesIMC[1] = 23.5;
                        nivelesIMC[2] = 28.2;
                        break;
                    default:
                        nivelesIMC[0] = 0;
                        break;

                }
            }
            return nivelesIMC;
        }
    }
}
