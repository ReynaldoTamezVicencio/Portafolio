﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace EV4E4AplMovRTV
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            pkSexo.Items.Add("Hombre");
            pkSexo.Items.Add("Mujer");
        }

        private void btnCalcular_Clicked(object sender, EventArgs e)
        {
            String nombre = txtNombre.Text;
            DateTime fechaNac = pkDate.Date;
            String sexo = pkSexo.SelectedItem.ToString();
            double peso = Convert.ToDouble(txtPeso.Text);
            double altura = Convert.ToDouble(txtaltura.Text);

            //, pkDate, pkSexo.SelectedItem.ToString(),
            //    Convert.ToInt32(txtPeso), Convert.ToInt32(txtaltura)

            Persona P1 = new Persona(nombre, fechaNac, sexo, peso, altura);
            int anios = P1.calculaEdad();
            double IMC = P1.CalcularIMC();
            double[] NivelesIMC = new double[3];
            NivelesIMC = P1.Calcularsalud();
            alertaSalud(Convert.ToString(IMC));
            if(NivelesIMC[0] == 0)
            {
                alertaSalud("No se tienen los datos para tu edad prueba en un rango de 11 a 15 años.");
            }
            else if (IMC <= NivelesIMC[0])
            {
                alertaSalud("Edad " + Convert.ToString(anios) + " El límite es " + Convert.ToString(NivelesIMC[0]) + 
                    " Tu IMC es de " + Convert.ToString(IMC) + " y el nivel de salud es Bajo Peso");
            }

            else if (IMC < NivelesIMC[1])
            {
                alertaSalud("Edad " + Convert.ToString(anios) + " El límite es " + Convert.ToString(NivelesIMC[1]) +
                    " Tu IMC es de " + Convert.ToString(IMC) + " y el nivel de salud es Normal");
            }

            else if (IMC < NivelesIMC[2])
            {
                alertaSalud("Edad " + Convert.ToString(anios) + " El límite es " + Convert.ToString(NivelesIMC[2]) +
                    " Tu IMC es de " + Convert.ToString(IMC) + " y el nivel de salud es Sobre Peso");
            }

            else if (IMC >= NivelesIMC[2])
            {
                alertaSalud("Edad " + Convert.ToString(anios) + " El límite es " + Convert.ToString(NivelesIMC[3]) +
                    " Tu IMC es de " + Convert.ToString(IMC) + " y el nivel de salud es Obesidad");
            }
        }

        private async void alerta(int dato)
        {
            await DisplayAlert("Datos", Convert.ToString(dato), "OK");
        }

        private async void alertaSalud(String salud)
        {
            await DisplayAlert("Estado de Salud",": " + salud, "OK");
        }
    }
}
