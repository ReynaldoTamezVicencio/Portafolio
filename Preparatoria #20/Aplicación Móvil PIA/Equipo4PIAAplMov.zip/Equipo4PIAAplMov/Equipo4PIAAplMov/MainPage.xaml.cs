﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Equipo4PIAAplMov
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
        
        private async void btnCalificar_Clicked(object sender, EventArgs e)
        {


            bool respuesta = await DisplayAlert("Retroalimentación","Hola "+ txtNombre.Text + 
                " ¿Está satisfecho con nuestros servicios?", "Si, completamente", "No, o parcialmente");
            if (respuesta == true)
            {
                await DisplayAlert("Retroalimentación", "¡Gracias! su respuesta se ha enviado. Nos alegra escuchar esta respueta.","Ok");
                txtNombre.Text = "";
                txtMatricula.Text = "";
                txtGrupo.Text = "";
   
            }
            else
            {
                string texto = await DisplayPromptAsync("Retroalimentación", "Explique cuáles son los motivos", placeholder: "Motivos");
                await DisplayAlert("Retroalimentación", "¡Gracias! su respuesta se ha enviado. Nos encargaremos de corregir esos problemas " +
                    "para brindar un óptimo servicio.   " + "Los problemas a resolver son: " + texto, "Ok");
                txtNombre.Text = "";
                txtMatricula.Text = "";
                txtGrupo.Text = "";
                
            }

        }
    }
}
